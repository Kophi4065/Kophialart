Kophialart Bot - Full project generated for Koyeb (Pairing Code mode)

- Replace media/logo.png with your real logo.
- To pair: deploy on Koyeb, check logs for pairing code, use WhatsApp Linked Devices -> Link device -> Enter code.
- Do NOT commit auth/ to public repos if it contains real credentials.
